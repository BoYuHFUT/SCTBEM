close all;clear;clc;
%Description of the problem: The potential distribution of a sphere with radius 1 is calculated. 
%The surface is divided into 864 four-node elements, including 866 boundary nodes, 
%and 866 inner points are distributed inside the sphere.
%Given the first kind of boundary condition u=exp(x), solve the internal node potential.
%Exact solution:u=exp(x)
%Authors:Bo Yu; Ruijiang Jing
%Journal Information:SCTBEM: A scaled coordinate transformation boundary element method with 99-line MATLAB code
%for solving Poisson's equation. Computer Physics Communications, 300(2024)109185.

%-------------------------------------------------------------------------%
% Input
% NBE:          Number of boundary elements
% NBP:          Number of boundary nodes
% NIP:          Number of interior points
% NTP:          Number of boundary nodes and interior points   
% S.ELE:        Connectivity information of all boundary elements
% S.CD:         Coordinates of nodes and inner points   
% S.BC:         Potential boundary conditions   
% S.true:       Analytical solution of the internal point potential    
%
% Output
% UTV:          Potentials of boundary and interior points
% QBV:          Flux of boundary points
%-------------------------------------------------------------------------%
NBE=864;NBP=866;NIP=866;NTP=NIP+NBP; 
S.ELE=load('ele.txt');S.CD=[load('coord.txt');load('coord.txt')/2];%Read the element node information
S.BC=exp(S.CD(1:NBP,1));S.true=exp(S.CD(NBP+1:NTP,1));%Imposed boundary condition

%% A novel boundary element method for solving 3D potential sprobGlemswith 99 lines Matlab codes
%% main program
GP=[0.577350269189626, -0.577350269189626];%Gaussian points
[HM,GM]=FORM_HG(S,NTP,NBP,NBE,GP);%Calculate H,G matrix
SCT=FORM_SCT(S,NTP,NBE,GP);%Domain integral
[UTV,QBV]=OUTPUT(HM,GM,S,SCT,NBP,NIP);
%-------------------------------------------------------------------------%
%This line is used to evaluate the results of the interior point potential 
%calculation, outputting the maximum absolute error and the root mean square error.
[abserrmax,RMSE]=err(UTV,NBP,NTP,S);
%-------------------------------------------------------------------------%
%% Calculate H,G matrix
function [HM,GM]=FORM_HG(S,NTP,NBP,NBE,GP)
HM=zeros(NTP,NBP);GM=HM;
[TEMP_HG1,TEMP_HG2]=ndgrid(GP);%Vectorized Gaussian pointsSING
[SP,DSP1,DSP2]=SHAPEF([zeros(4,1),[TEMP_HG1(:),TEMP_HG2(:)]]);%Calculate the shape function corresponding to the Gauss point
DIS_SFALL=squareform(pdist(S.CD(:,1:3)));%Calculate the distance of all the points
for i=1:NBE%Element loops and vectorized node loops
    CK=S.CD(S.ELE(i,:),1:3);CKX=(SP*CK(:,1))'-S.CD(:,1);
    CKY=(SP*CK(:,2))'-S.CD(:,2);CKZ=(SP*CK(:,3))'-S.CD(:,3);
    DIS_SF=DIS_SFALL(:,S.ELE(i,:));DIS_GAU=sqrt(CKX.^2+CKY.^2+CKZ.^2);
    [SINN,~]=find(DIS_SF==0);%Search for singularity
    for j=1:4%Singular integrals are computed by element subdivision
        SING=SETDSUB(CK,S.CD(SINN(j),1:3),DIS_SF(SINN(j),:),SP,DSP1,DSP2);
        GM(SINN(j),S.ELE(i,:))=SING+GM(SINN(j),S.ELE(i,:));
    end
    PRODUCT=cross((DSP1*CK),(DSP2*CK));%The cross product of any two vectors on the element
    JACHG=vecnorm(PRODUCT,2,2);%Calculate the Jacobian
    n=PRODUCT./JACHG;
    DIS_NE=CKX.*n(:,1)'+CKY.*n(:,2)'+CKZ.*n(:,3)';%Distance from source point to element
    for j=1:4
        TEMP=(0.25/pi*JACHG.*SP(:,j))'./DIS_GAU;
        hm=sum(-TEMP.*DIS_NE./DIS_GAU.^2,2);
        gm=sum(TEMP,2);hm(SINN)=0;gm(SINN)=0;
        HM(:,S.ELE(i,j))=hm+HM(:,S.ELE(i,j));
        GM(:,S.ELE(i,j))=gm+GM(:,S.ELE(i,j));
    end
end
for i=1:NBP
    HM(i,i)=-sum(HM(i,:));%Compute the principal diagonal elements of the H matrix
end
end
%% Singular integrals are computed by element subdivision
function [SING] = SETDSUB(CK,XP,DIS_SF,SP,DSP1,DSP2)
X_SUB1=[-1,1,1,-1];X_SUB2=X_SUB1;Y_SUB1=[-1,-1,1,1];Y_SUB2=Y_SUB1;%Initial local coordinate
k=find(DIS_SF==0);
switch k(1)%Identify the location of the source point
    case 1
        X_SUB1(4)=-1;Y_SUB1(4)=-1;X_SUB2(2)=-1;Y_SUB2(2)=-1;
    case 2
        X_SUB1(3)=1;Y_SUB1(3)=-1;X_SUB2(1)=1;Y_SUB2(1)=-1;
    case 3
        X_SUB1(4)=1;Y_SUB1(4)=1;X_SUB2(2)=1;Y_SUB2(2)=1;
    case 4
        X_SUB1(3)=-1;Y_SUB1(3)=1;X_SUB2(1)=-1;Y_SUB2(1)=1;
end
[SP1,DSP1_1,DSP2_1]=SHAPEF([zeros(4,1),SP*X_SUB1',SP*Y_SUB1']);
[SP2,DSP1_2,DSP2_2]=SHAPEF([zeros(4,1),SP*X_SUB2',SP*Y_SUB2']);
JACSUB1=vecnorm(cross(DSP1_1*CK,DSP2_1*CK),2,2)*0.25/pi;
JACSUB2=vecnorm(cross(DSP1_2*CK,DSP2_2*CK),2,2)*0.25/pi;
TEMP_SUB3=abs(DSP1*X_SUB1'.*DSP2*Y_SUB1'-DSP1*Y_SUB1'.*DSP2*X_SUB1')...
    ./vecnorm(SP1*CK-XP,2,2);
TEMP_SUB4=abs(DSP1*X_SUB2'.*DSP2*Y_SUB2'-DSP1*Y_SUB2'.*DSP2*X_SUB2')...
    ./vecnorm(SP2*CK-XP,2,2);
SING=sum(TEMP_SUB3.*JACSUB1.*SP1+TEMP_SUB4.*JACSUB2.*SP2);
end
%% Domain integral
function [SCT] = FORM_SCT(S,NTP,NBE,GP)
SCT=zeros(NTP,1);Xdi=reshape(S.CD(S.ELE,1),NBE,4)';
Ydi=reshape(S.CD(S.ELE,2),NBE,4)';Zdi=reshape(S.CD(S.ELE,3),NBE,4)';
[TEMP_DI1,TEMP_DI2,TEMP_DI3]=ndgrid(GP);%Vectorized Gaussian points
[SP,DSP1,DSP2]=SHAPEF([TEMP_DI1(:),TEMP_DI2(:),TEMP_DI3(:)]);%Calculate the shape function corresponding to the Gauss point
TWMP_DI4=0.5*(1+TEMP_DI1(:)).*SP;TEMP_DI5=0.5*(1+TEMP_DI1(:))*0.125/pi;
for j=1:NTP
    Xdi_=Xdi-S.CD(j,1);Ydi_=Ydi-S.CD(j,2);Zdi_=Zdi-S.CD(j,3);%Coordinate transformation
    XS=TWMP_DI4*Xdi_+S.CD(j,1);%x,y,z in the scaled boundary coordinate system
    DSP1X=DSP1*Xdi_;DSP1Y=DSP1*Ydi_;DSP1Z=DSP1*Zdi_;DSP2X=DSP2*Xdi_;
    DSP2Y=DSP2*Ydi_;DSP2Z=DSP2*Zdi_;
    SPX=(SP*Xdi_);SPY=SP*Ydi_;SPZ=SP*Zdi_;
    TEMP_DI6=SPX.*((DSP1Y).*(DSP2Z)-(DSP2Y).*(DSP1Z));
    TEMP_DI7=SPY.*((DSP1Z).*(DSP2X)-(DSP1X).*(DSP2Z));
    TEMP_DI8=SPZ.*((DSP1X).*(DSP2Y)-(DSP1Y).*(DSP2X));
    FUNDSOL=sqrt((SPX).^2+(SPY).^2+(SPZ).^2);
    JACB=(abs(TEMP_DI6+TEMP_DI7+TEMP_DI8)./FUNDSOL);%Calculate the Jacobian
    SCT(j)=sum(sum(JACB.*TEMP_DI5.*exp(XS)));
end
end
%% Solving equations of linear equations
function [UTV,QBV] = OUTPUT(HM,GM,S,SCT,NBP,NIP)
HM=[HM,[zeros(NBP,NIP);eye(NIP)]];
TEMP_OUT=HM(:,1:NBP);HM(:,1:NBP)=-GM(:,1:NBP);GM(:,1:NBP)=-TEMP_OUT;
UTV=gmres(HM,GM*S.BC-SCT,20,1e-6);
TEMP_OUT=UTV(1:NBP);UTV(1:NBP)=S.BC(1:NBP);QBV(1:NBP)=TEMP_OUT;
end
%% Calculation of four-node shape function
function [SP,DSP1,DSP2] = SHAPEF(GPM)
SP1=(1-GPM(:,2)).*(1-GPM(:,3));SP2=(1+GPM(:,2)).*(1-GPM(:,3));
SP3=(1+GPM(:,2)).*(1+GPM(:,3));SP4=(1-GPM(:,2)).*(1+GPM(:,3));
DSP1_1=GPM(:,3)-1;DSP1_2=-DSP1_1;DSP1_3=1+GPM(:,3);DSP1_4=-DSP1_3;
DSP2_1=GPM(:,2)-1;DSP2_2=-1-GPM(:,2);DSP2_3=-DSP2_2;DSP2_4=-DSP2_1;
SP=0.25*[SP1,SP2,SP3,SP4];DSP1=0.25*[DSP1_1,DSP1_2,DSP1_3,DSP1_4];
DSP2=0.25*[DSP2_1,DSP2_2,DSP2_3,DSP2_4];
end
%-------------------------------------------------------------------------%
%% Error evaluation
function [abserrmax,RMSE]=err(UTV,NBP,NTP,S)
abserr=abs(S.true-UTV((NBP+1):NTP));
plot(1:(NTP-NBP),abserr,'-r*');
title('Absolute error of interior point potential');
xlabel('Interior point number');
ylabel('Absolute Error')
abserrmax=max(abserr);
RMSE=(mean(abserr.^2))^0.5;
end





